package Symbol;

public enum FuncType {
    INT,VOID
}
