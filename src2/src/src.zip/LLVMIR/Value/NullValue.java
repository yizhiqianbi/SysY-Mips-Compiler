package LLVMIR.Value;
//! 不记得null 是不是有这个文法了
public class NullValue extends Value{
    private boolean isConst;

}
