package LLVMIR.Value;

public class Function extends Value{

}
