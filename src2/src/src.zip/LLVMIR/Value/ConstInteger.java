package LLVMIR.Value;

public class ConstInteger extends Value{
}
