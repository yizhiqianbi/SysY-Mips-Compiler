package LLVMIR.Value;

public class BasicBlock extends Value{
}
