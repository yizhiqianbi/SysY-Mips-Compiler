package LLVMIR.Value;

public class Argument extends Value{
}
