package LLVMIR.Value;

public class ConstFloat {
}
