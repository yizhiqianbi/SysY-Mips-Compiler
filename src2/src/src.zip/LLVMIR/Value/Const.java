package LLVMIR.Value;

public class Const extends Value{
}
