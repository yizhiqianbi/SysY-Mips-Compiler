package LLVMIR;

public class Visitor {
}


