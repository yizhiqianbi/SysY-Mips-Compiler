package Frontend.AST;

public class BreakAST extends IASTNode{
}
