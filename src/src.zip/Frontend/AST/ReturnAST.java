package Frontend.AST;

public class ReturnAST extends IASTNode{
}
