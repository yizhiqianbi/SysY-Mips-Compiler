package Frontend.AST;

public class BaseAST extends IASTNode{
}
