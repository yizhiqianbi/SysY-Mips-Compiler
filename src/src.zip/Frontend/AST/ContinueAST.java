package Frontend.AST;

public class ContinueAST extends IASTNode{
}
