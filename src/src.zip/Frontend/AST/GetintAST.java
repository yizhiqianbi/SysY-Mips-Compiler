package Frontend.AST;

public class GetintAST extends IASTNode{
}
