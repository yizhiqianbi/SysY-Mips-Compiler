package Frontend.AST;
public class BType extends IASTNode{


}
