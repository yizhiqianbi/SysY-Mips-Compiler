package LLVMIR.Value.Instruction;

public class Phi  {
}
