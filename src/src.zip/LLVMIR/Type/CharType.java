package LLVMIR.Type;

public class CharType extends Type {
    char ch;
    public CharType(char ch){
        this.ch = ch;
    }

    public char getCh() {
        return ch;
    }

    public void setCh(char ch) {
        this.ch = ch;
    }

    @Override
    public boolean isCharType() {
        return true;
    }
}
