package LLVMIR.Type;

public class LableType extends Type{
    @Override
    public boolean isLableType() {
        return true;
    }
}
